package com.example.softlabexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoftlabExamApplicationTests {

    @Test
    void contextLoads() {
    }

}
